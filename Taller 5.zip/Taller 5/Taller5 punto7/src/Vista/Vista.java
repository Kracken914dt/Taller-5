package Vista;
import modelo.*;
import java.util.Scanner;
import java.util.Collections;
public class Vista {
    public static void main(String[] args) {
        Materia Materiatodas =new Materia();
        Materiatodas.crearGrupos();
        Grupos_Estudiantes TodosGrupos=new Grupos_Estudiantes();
        TodosGrupos.Grupo();
        crearAsignatura();
    }
    public static void crearAsignatura(){
        String nombre_asig,codigo_asig;
        Scanner entrada=new Scanner(System.in);
        System.out.println("----------------------------------------");
        System.out.println("CREAR ASIGNATURA");
        System.out.println("Nombre de la asignatura: ");
        nombre_asig=entrada.next();
        System.out.println("Codigo de la asignatura: ");
        codigo_asig=entrada.next();
        int []num_grupo=new int[3];
        String []docente=new String[3];
        String []nombre= new String[3];
        String []apellidos= new String[3];
        double []notas=new double [3];
        for (int i=0;i<3;i++){
            System.out.println("Numero del grupo: "+(i+1));
            num_grupo[i]=entrada.nextInt();
            System.out.println("Docente a cargo del grupo: "+(i+1));
            docente[i]=entrada.next();
            for (int j=0;j<3;j++){
                System.out.println("-------------------------------------------------------");
                System.out.println("Escriba el nombre del estudiante "+(j+1));
                nombre[j]=entrada.next();
                System.out.println("Escriba el apellido del estudiante "+(j+1));
                apellidos[j]=entrada.next();
                for (int x=0;x<3;x++){
                    System.out.println("Escriba la nota del periodo "+(x+1));
                    notas[x]=entrada.nextDouble();
                }
            }
            System.out.println("-------------------------------------------------");
            System.out.println("Nombre Asignatura: "+nombre_asig);
            System.out.println("Codigo Asignatura: "+codigo_asig);
            System.out.println("Docente a cargo: "+docente);
            System.out.println("Primer nombre del estudiante: "+nombre);
            System.out.println("Primer apellido del estudiante: "+apellidos);
            for (int j=0;j<notas.length;j++){
            System.out.println("Nota del periodo "+(j+1)+": "+notas[j]);
            }
        }  
    }
    
}
