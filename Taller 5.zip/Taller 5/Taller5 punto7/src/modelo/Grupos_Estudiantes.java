
package modelo;
public class Grupos_Estudiantes {
    private String Nombre_asignatura,Nombre_Estudiantes,Apellido_Estudiante,Codigo,Docente;
    private int Grupos;
    private double []notas={4.2,3.2,5.0};
    
    public Grupos_Estudiantes() {
        this.Nombre_Estudiantes = "Juan";
        this.Apellido_Estudiante = "Rodriguez";
        this.Docente = "Elliot Paul";
        this.Grupos = 2;
        this.notas = notas;
    }
    
    public String getNombre_Estudiantes() {
        return Nombre_Estudiantes;
    }

    public void setNombre_Estudiantes(String Nombre_Estudiantes) {
        this.Nombre_Estudiantes = Nombre_Estudiantes;
    }

    public String getApellido_Estudiante() {
        return Apellido_Estudiante;
    }

    public void setApellido_Estudiante(String Apellido_Estudiante) {
        this.Apellido_Estudiante = Apellido_Estudiante;
    }


    public String getDocente() {
        return Docente;
    }

    public void setDocente(String Docente) {
        this.Docente = Docente;
    }
    
    public void Imprimir_Notas(){
        for (int i=0;i<notas.length;i++){
            System.out.println("Nota del periodo "+(i+1)+": "+notas[i]);
        }
    }
    public void Grupo(){
        System.out.println("Docente que esta a cargo: "+getDocente());
        System.out.println("Primer Nombre de Estudiante: "+getNombre_Estudiantes());
        System.out.println("Primer Apellido de Estudiante: "+getApellido_Estudiante());
        Imprimir_Notas();
    }  
}