package modelo;

import java.util.Scanner;

public class Materia {
    Scanner entrada= new Scanner(System.in);
    private String Nombre_Materia;
    private String Codigo_Materia;
    private int Grupos;
  
    public Materia(){
        this.Nombre_Materia="Programacion";
        this.Codigo_Materia="4h295";
    }
    public int getGrupos() {
        return Grupos;
    }
    public void setGrupos(int Grupos) {
        this.Grupos = Grupos;
    }
    public String getNombreMateria() {
        return Nombre_Materia;
    }
    public void setNombreMateria(String Nombre_Materia) {
        this.Nombre_Materia = Nombre_Materia;
    }
    public String getCodigoMateria() {
        return Codigo_Materia;
    }
    public void setCodigoMateria(String Codigo_Materia) {
        this.Codigo_Materia = Codigo_Materia;
    }
    public void crearGrupos(){
        System.out.println("Nombre Asignatura: "+getNombreMateria());
        System.out.println("Codigo Asignatura: "+getCodigoMateria());

    }  
    
    
}
