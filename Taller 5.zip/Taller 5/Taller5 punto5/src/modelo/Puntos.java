
package modelo;

public class Puntos {
private int X;
private int Y;
private double a;
private double b;

// Punto
    public Puntos() {
        this.X = 0;
        this.Y = 0;
    }
// coordena
    public Puntos(double a, double b) {
        this.a = a;
        this.b = b;
    }

    public double getA() {
        return a;
    }

    public void setA(double a) {
        this.a = a;
    }

    public double getB() {
        return b;
    }

    public void setB(double b) {
        this.b = b;
    }
    

    public int getX() {
        return X;
    }

    public void setX(int X) {
        this.X = X;
    }

    public int getY() {
        return Y;
    }

    public void setY(int Y) {
        this.Y = Y;
    }
    public double calcularDistancia(){
        int dX = (int) (a - this.X);
        int dY = (int) (b - this.Y);

        double X2 = Math.pow(dX, 2);
        double Y2 = Math.pow(dY, 2);

        double distancia = Math.sqrt(X2 + Y2);
        return distancia;

    }
    
    
}
