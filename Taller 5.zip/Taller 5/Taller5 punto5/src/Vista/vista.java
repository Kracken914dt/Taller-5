
package Vista;
import modelo.Puntos;
import java.util.Scanner;
public class vista {
    public static void main(String[] args) {
        Scanner Leer = new Scanner(System.in);
        System.out.println("Introduzca la coordenada del punto 1: ");
        System.out.println("Punto 1 coordenada X: ");
        int CX = Leer.nextInt();
        System.out.println("Punto 1 coordenada Y: ");
        int CY = Leer.nextInt();
        System.out.println("Introduzca las otras dos coordenadas del punto 1: ");
        System.out.println("Punto 1 coordenada X: ");
        int DX = (int) Leer.nextDouble();
        System.out.println("Punto 1 coordenada Y: ");
        int DY = (int) Leer.nextDouble();
        
        Puntos punto1 = new Puntos();
        punto1.setX(DX);
        punto1.setY(DY);
        punto1.setA(CX);
        punto1.setB(CY);
        System.out.println("Distancia 1: "+punto1.calcularDistancia());
        
    }
}
