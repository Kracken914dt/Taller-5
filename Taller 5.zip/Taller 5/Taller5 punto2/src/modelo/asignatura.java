package modelo;

import java.util.Scanner;

import java.util.Scanner;
public class asignatura {
    Scanner entrada= new Scanner(System.in);
    private String nombre_asig,codigo_asig;
    private int num_grupos;
  
    public asignatura(){
        this.nombre_asig="matematicas";
        this.codigo_asig="0500A";
    }
    public int getNum_grupos() {
        return num_grupos;
    }
    public void setNum_grupos(int num_grupos) {
        this.num_grupos = num_grupos;
    }
    public String getNombre_asig() {
        return nombre_asig;
    }
    public void setNombre_asig(String nombre_asig) {
        this.nombre_asig = nombre_asig;
    }
    public String getCodigo_asig() {
        return codigo_asig;
    }
    public void setCodigo_asig(String codigo_asig) {
        this.codigo_asig = codigo_asig;
    }
    public void crearGrupos(){
        System.out.println("Nombre Asignatura: "+getNombre_asig());
        System.out.println("Codigo Asignatura: "+getCodigo_asig());

    }  
    
    
}
