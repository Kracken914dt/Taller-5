package modelo;
import modelo.Texto;
import java.util.Scanner;
public class Vista {
    public static void main(String[] args) {

        Scanner leer = new Scanner(System.in);

        Texto Texto1 = new Texto();
        int opciones;
        boolean continuar = true;

        while (continuar == true) {
            System.out.println("------------------------------------------------------------------------------------------------------");
            System.out.println("ESCOJA UNA OPCION: ");
            System.out.println("1. El número de vocales existentes en el texto. ");
            System.out.println("2. El número de consonantes en el texto. ");
            System.out.println("3. El número de repeticiones existentes en el texto de una palabra. ");
            System.out.println("4. La vocal que más repeticiones presenta en el texto. ");
            System.out.println("5. El número de palabras en el párrafo. ");
            System.out.println("6. Imprime la palabra más larga del texto y su tamaño. ");
            System.out.println("7. Salir ");
            System.out.println("------------------------------------------------------------------------------------------------------");
            opciones = leer.nextInt();
            if (opciones == 1) {
                System.out.println("por favor ingrese la palabra o texto a verificar: ");
                System.out.println("El texto contiene " + Texto1.numero_Vocales()+ " vocales ");
            } else if (opciones == 2) {
                System.out.println("por favor ingrese la palabra o texto a verificar: ");
                System.out.println("El texto contiene " + Texto1.numero_Consonantes()+ " consonantes ");
            } else if (opciones == 3) {
                System.out.println("por favor ingrese la palabra y luego el  texto a  verificar: ");
                System.out.println("El texto contiene " + Texto1.buscar() + " veces repetida la palabra ");   
            } else if (opciones == 4) {
                System.out.println("por favor ingrese la palabra y luego el  texto a  verificar: ");
                System.out.println("La vocal  " + Texto1.vocalMayor()+ " ");
            } else if (opciones == 5) {
                System.out.println("por favor ingrese la palabra y luego el  texto a  verificar: ");
                System.out.println("El numero de palabras en el parrafo es:   " + Texto1.numero_Palabras()+ " ");  
            } else if (opciones == 6) {
                System.out.println("por favor ingrese la palabra a  verificar: ");
                System.out.println("La palabra mas larga del texto es:  " + Texto1.palabrasMayor()+ " ");  
            } else if (opciones == 7) {
                continuar = false;
                System.out.println("Gracias por usar mi programa ");
            }
        }

    }

}
