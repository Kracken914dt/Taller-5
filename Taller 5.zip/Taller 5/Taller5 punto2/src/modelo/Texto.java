package modelo;

import java.io.Console;
import java.util.Scanner;

public class Texto {

    private String textos;
    private String oracion;
    private String palabra;
    private char [] vocales={'a','e','i','o','u'};
    private char [] consonantes={'B','C','D','F','G','H','J','K','L','M','N','Ñ','P','Q','R','S','T','V','X','Z','W','Y'};
    
  
    public Texto() {

    }

    public String gettextos() {
        return this.textos;
    }

    public void settextos(String textos) {
        this.textos = textos;
    }

    public int numero_Vocales() {
        textos=Leer();
        int contadorvocales=0; 
        for (int i = 0; i < textos.length(); i++) { 
            for (int j = 0; j < vocales.length; j++) { 
                if (vocales[j] == Character.toLowerCase(textos.charAt(i))){  
                    contadorvocales += 1;
                           
                }
                
            }      
        }
        return contadorvocales;
    }
    public int numero_Consonantes() {
        textos=Leer();
        int contadorconsonates=0;
        for (int i = 0; i < textos.length(); i++) {
            for (int j = 0; j < consonantes.length; j++) {
                if (Character.toLowerCase(consonantes[j]) == Character.toLowerCase(textos.charAt(i))) {
                    contadorconsonates += 1;
                    
                }
                
            }
            
        }
        return contadorconsonates;
    }

    public int buscar(){
        Console cns = System.console();
        int contadorpalabras=0;
        String textos=cns.readLine(); 
        oracion=cns.readLine();
        String[] palabras = oracion.split(" ");
        contadorpalabras = 0;
        for (int i = 0; i < palabras.length-1; i++) { 
            if (textos.equals(palabras[i]));
            System.out.println(textos+" : "+palabras[i]);
            contadorpalabras += 1;   
        }
    return contadorpalabras;
    }
    public int vocalMayor(){
        textos=Leer();
        int [] moda={0,0,0,0,0};
        for (int i = 0; i < textos.length(); i++) { //recorrer el vector vocales que tiene las vocales
            for (int j = 0; j < vocales.length; j++) { //recorrear cada una de las posicones de la variable texto
                if (vocales[j] == Character.toLowerCase(textos.charAt(i))){  
                    switch(textos.charAt(i)){
                        case 'a':
                            moda[0]+=1;
                            break;
                        case 'e':
                            moda[1]+=1;
                            break;
                        case 'i':
                            moda[2]+=1;
                            break;
                        case 'o':
                            moda[3]+=1;
                            break;
                        case 'u':
                            moda[4]+=1;
                            break;  
                    }
                           
                }
                
            }      
        }
        int mayor=0;
        for (int i = 0; i < 5; i++) {
            System.out.println(moda[i]);
            if (moda[i]<mayor){
                mayor=i;
                
            }  
        }
        return moda[mayor];
        
    }
    public int numero_Palabras(){
        String [] oraciones =Leer().split(" ");
        return oraciones.length;   
    }
    public String palabrasMayor(){
        String [] oraciones =Leer().split(" ");
        int mayor2=0;
        for (int i = 0; i < oraciones.length; i++) {
            if (oraciones[i].length()>mayor2){
                mayor2=i;
                
            }  
        }
        return oraciones[mayor2];
        
    }
    public String Leer(){
        Scanner Leer = new Scanner(System.in);
        textos=Leer.nextLine();
        return textos;
    }
}
