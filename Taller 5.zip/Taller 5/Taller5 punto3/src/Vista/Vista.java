package Vista;

import java.util.Scanner;
import modelo.Campeonato;
public class Vista {
    public static void main(String[] args) {
    Scanner entrada= new Scanner(System.in);
    String NombreEquipo;
    String Ciudad_Origen;
    String Nombre_Tecnico;
    int numero_Inscripcion;
    int Jugadores;
    String [] NombreJugador= new String [20];
    int [] Edad = new int [20];
    String [] Posicion = new String [20] ;
    int N,N2,N3=0;
    int N1=0;
        System.out.println("No puedes pasar el limite de 5 equipos");
    System.out.println("Digite el numero de equipos:");
    N = entrada.nextInt();
    
    Campeonato op[] = new Campeonato[N];
    for (int x=0;x<N;x++){
        entrada.nextLine();
        System.out.print("");
        System.out.print("Digite nombre del equipo: ");
        NombreEquipo = entrada.nextLine();
        System.out.print("Digite la ciudad de origen del equipo: ");
        Ciudad_Origen = entrada.nextLine();
        System.out.print("Digite el nombre del tecnico(equipo): ");
        Nombre_Tecnico = entrada.nextLine();
        System.out.print("Digite Numero de inscripcion: ");
        numero_Inscripcion = entrada.nextInt();
        System.out.print("Digite de jugadores que desea inscribir en el equipo (No puedes pasar el limite de 6 ): ");
        Jugadores = entrada.nextInt();
        N2= Jugadores+N3;
        
        for (int i=N1; i<N2;i++){
            entrada.nextLine();
            System.out.print("Digite el nombre del jugador "+(i+1)+" : ");
            NombreJugador [i]= entrada.nextLine();
            System.out.print("Digite la edad del jugador "+(i+1)+" : ");
            Edad [i]=entrada.nextInt();
            System.out.print("Digite la posicion del jugador "+(i+1)+" : ");
            Posicion [i] = entrada.next();
            System.out.print("");
            N1++;
            N3++;
        }
        
    op[x]= new Campeonato(NombreEquipo, Ciudad_Origen,Nombre_Tecnico,numero_Inscripcion,Jugadores, NombreJugador , Edad ,Posicion);
    }
    
    
    for (int i=0;i<op.length;i++){
        System.out.println("\n--- Nomina del equipo "+(i+1)+" ---");
        op[i].Mostrar_Datos();
        System.out.println("");
    }
    System.out.println("--- Nomina de los jugadores ---");
    for (int i=0; i<N1;i++){
        System.out.println("-------------------------------------------------------------------");
        System.out.println("Este es el nombre del jugador: "+(i+1)+":  "+NombreJugador[i]);
        System.out.println("Esta es la edad del jugador "+(i+1)+": "+Edad[i]);
        System.out.println("Esta es la posicion del jugador:  "+(i+1)+": "+Posicion[i]);
       
    }
    }
}
