package modelo;
import java.util.Scanner;
public class Campeonato {
    Scanner entrada = new Scanner (System.in);
    int a[]= new int [3];
    private int [] Equipo;
    private String Nombre_Equipo;
    private String Ciudad_Origen;
    private String Nombre_Tecnico;
    private int Numero_Inscripcion;
    private int Jugadores;
    private String [] Nombre_Jugador = new String [20];
    private int [] Edad = new int [20];
    private String [] Posicion= new String [20];

    public Campeonato(String Nombre_Equipo, String Ciudad_Origen, String Nombre_Tecnico, int Numero_Inscripcion, int Jugadores, String [] Nombre_Jugador, int [] Edad, String [] Posicion) {
       
        this.Nombre_Equipo = Nombre_Equipo;
        this.Ciudad_Origen = Ciudad_Origen;
        this.Nombre_Tecnico = Nombre_Tecnico;
        this.Numero_Inscripcion = Numero_Inscripcion;
        this.Nombre_Jugador = Nombre_Jugador;
        this.Edad = Edad;
        this.Posicion = Posicion;
    }

    public int getJugadores() {
        return Jugadores;
    }

    public void setJugadores(int Jugadores) {
        this.Jugadores = Jugadores;
    }

     public String getNombre_Jugador() {
        return Nombre_Jugador [20];
    }

    public void setNombreJugador(String [] Nombre_Jugador) {
        this.Nombre_Jugador = Nombre_Jugador;
    }

    public String getCiudad_Origen() {
        return Ciudad_Origen;
    }

    public void setCiudad_Origen(String Ciudad_Origen) {
        this.Ciudad_Origen = Ciudad_Origen;
    }

    public String getNombre_Tecnico() {
        return Nombre_Tecnico;
    }

    public void setNombre_Tecnico(String Nombre_Tecnico) {
        this.Nombre_Tecnico = Nombre_Tecnico;
    }

    public int getNumero_Inscripcion() {
        return Numero_Inscripcion;
    }

    public void setNumero_Inscripcion(int Numero_Inscripcion) {
        this.Numero_Inscripcion = Numero_Inscripcion;
    }
    

    public int getEdad() {
        return Edad [20];
    }

    public void setEdad(int [] Edad) {
        this.Edad = Edad;
    }

    public String getPosicion() {
        return Posicion [20];
    }

    public void setPosicion(String [] posicion) {
        this.Posicion = posicion;
    }

    public int[] getEquipo() {
        return Equipo;
    }

    public void setEquipo(int[] Equipo) {
        this.Equipo = Equipo;
    }
    
    
    public void Mostrar_Datos(){
        System.out.print("");
        System.out.println("El nombre del equipo es: "+Nombre_Equipo);
        System.out.println("La ciudad del equipo es: "+Ciudad_Origen);
        System.out.println("El nombre del tecnico es: "+Nombre_Tecnico);
        System.out.println("El numero de inscripcion es: "+Numero_Inscripcion);
        //System.out.println("Numero de jugadores del equipo: "+jugadores);
        for (int i=0; i<Jugadores;i++){
            System.out.println("El nombre del jugador "+(i+1)+" es: "+Nombre_Jugador[i]);
            System.out.println("La edad del jugador "+(i+1)+" es: "+Edad[i]);
            System.out.println("La posicion donde juega el jugador "+(i+1)+" es: "+Posicion[i]);
            
        }
    }
    
    public void nominaJugadores(){
        for (int i=0;i<Jugadores;i++){
            System.out.println("El nombre del jugador "+(i+1)+" es: "+Nombre_Jugador[i]);
            System.out.println("La edad del jugador "+(i+1)+" es: "+Edad[i]);
            System.out.println("La posicion donde juega el jugador "+(i+1)+" es: "+Posicion[i]);
        }
    }
    
    
}
