
package modelo;

public class Direccion {
    private String Carrera;
    private String Barrio;
    private String Calle;

    public Direccion(String Calle, String Carrera, String Barrio) {
        this.Carrera = Carrera;
        this.Barrio = Barrio;
        this.Calle = Calle;
    }
    

    public String getCarrera() {
        return Carrera;
    }

    public void setCarrera(String Carrera) {
        this.Carrera = Carrera;
    }

    public String getBarrio() {
        return Barrio;
    }

    public void setBarrio(String Barrio) {
        this.Barrio = Barrio;
    }

    public String getCalle() {
        return Calle;
    }

    public void setCalle(String Calle) {
        this.Calle = Calle;
    }
  
    public void imprimirDireccionDomicilio(){
        System.out.println("La direccion de domicilio es: calle: "+getCalle()+ " carrera "+getCarrera() +" barrio "+getBarrio());
    }
    public void imprimirDireccionTrabajo(){
        System.out.println("La direccion de trabajo es: calle: "+getCalle()+ " carrera "+getCarrera() +" barrio "+getBarrio());
    }
}

