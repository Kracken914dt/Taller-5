package modelo;

public class Persona {
    private String Nombre;
    private String Apellido;
    private String Fecha_nacimiento;
    private String dirección_Domicilio;
    private String dirección_trabajo;

    
    public Persona(String Nombre, String Apellido) {
        this.Nombre = Nombre;
        this.Apellido = Apellido;
        this.Fecha_nacimiento = Fecha_nacimiento;
        this.dirección_Domicilio = dirección_Domicilio;
        this.dirección_trabajo = dirección_trabajo;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getApellido() {
        return Apellido;
    }

    public void setApellido(String Apellido) {
        this.Apellido = Apellido;
    }

    public String getFecha_nacimiento() {
        return Fecha_nacimiento;
    }

    public void setFecha_nacimiento(String Fecha_nacimiento) {
        this.Fecha_nacimiento = Fecha_nacimiento;
    }
  
      public String getDirección_Domicilio() {
        return dirección_Domicilio;
    }

    public void setDirección_Domicilio(String dirección_Domicilio) {
        this.dirección_Domicilio = dirección_Domicilio;
    }

    public String getDirección_trabajo() {
        return dirección_trabajo;
    }

    public void setDirección_trabajo(String dirección_trabajo) {
        this.dirección_trabajo = dirección_trabajo;
    }

    public void imprimirNombre_apellido(){
        System.out.println("Nombre: "+getNombre());
        System.out.println("Apellido: "+getApellido());
    }
 
}

