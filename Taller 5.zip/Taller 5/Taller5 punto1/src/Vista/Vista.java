
package Vista;
import modelo.Persona;
import modelo.Fecha;
import modelo.Direccion;
public class Vista {
    public static void main(String[] args) {
        
        // Persona 1
        Persona persona1 = new Persona("Juan", "jose");
        persona1.imprimirNombre_apellido();   
        
        Fecha Fecha1 = new Fecha("12", "Mayo", "2004");
        Fecha1.imprimirNacimiento();

        Direccion direccion1 = new Direccion("Calle 28","4ghj","Simon Bolivar");
        direccion1.imprimirDireccionDomicilio();
        
        Direccion direccion2 = new Direccion("Calle 14","ABC","Kennedy");
        direccion2.imprimirDireccionTrabajo();
        
        // Persona 2
        System.out.println("--------------------------------------------------------------------------------");
        
        Persona persona2 = new Persona("Carlos", "Martin");
        persona2.imprimirNombre_apellido();   
        
        Fecha Fecha2 = new Fecha("24", "Junio", "1995");
        Fecha2.imprimirNacimiento();

        Direccion direccion3 = new Direccion("Calle 31","4h29","Santa Rita");
        direccion3.imprimirDireccionDomicilio();
        
        Direccion direccion4 = new Direccion("Calle 45 ","Kol2","Mayales");
        direccion4.imprimirDireccionTrabajo();
        
          // Persona 3
        System.out.println("--------------------------------------------------------------------------------");
        
        Persona persona3 = new Persona("Elliot", "Alderson");
        persona3.imprimirNombre_apellido();   
        
        Fecha Fecha3 = new Fecha("17", "Septiembre", "1986");
        Fecha3.imprimirNacimiento();

        Direccion direccion5 = new Direccion("Calle 12","32","La panplona");
        direccion5.imprimirDireccionDomicilio();
        
        Direccion direccion6 = new Direccion("Calle 56 ","76","poyal");
        direccion6.imprimirDireccionTrabajo();
        
        
        
        
    }
    
    
}
